===== Mezan Shop =====

Mezan Shop plugin adds shop features for Mezan theme.


== Changelog ==

= 1.0.0 =

    * First release!