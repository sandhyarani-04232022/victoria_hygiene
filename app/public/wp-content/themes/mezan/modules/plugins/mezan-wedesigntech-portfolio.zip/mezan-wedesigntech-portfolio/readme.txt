===== Mezan WeDesignTech Portfolio =====

Mezan WeDesignTech Potfolio plugin adds complete portfolio modules to built portfolio section in your site.


== Changelog ==

= 1.0.1 =
    * Minor bug fixed


= 1.0.0 =

    * First release!