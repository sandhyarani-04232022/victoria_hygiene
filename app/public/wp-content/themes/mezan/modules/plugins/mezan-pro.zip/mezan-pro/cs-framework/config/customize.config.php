<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

CSFramework_Customize::instance( array() );