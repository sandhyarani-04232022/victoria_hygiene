===== Mezan WeDesignTech Elementor Addon =====

Mezan WeDesignTech Elementor Addon plugin adds additional modules for Elementor plugin.


== Changelog ==

= 1.0.4 =

    * Compatible: Latest Elementor version

= 1.0.3 =

    * Compatible: Latest Elementor version

= 1.0.2 =

    * Compatible: Latest Elementor version

= 1.0.1 =

    * Compatible: Latest Elementor version
    
= 1.0.0 =

    * First release!