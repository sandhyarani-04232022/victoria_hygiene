======= Mezan Plus =====

Mezan Plus plugin adds additonal features for Mezan theme.


== Changelog ==


= 1.0.2 =

  * Fixed: Translation issue & Minor bugs

= 1.0.1 =

  * Minor bug fixed

= 1.0.0 =

    * First release!