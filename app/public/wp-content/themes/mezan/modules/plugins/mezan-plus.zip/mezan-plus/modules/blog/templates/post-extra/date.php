<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Date -->
<div class="entry-date">
	<i class="wdticon-calendar"> </i>
	<?php echo get_the_date ( get_option('date_format') ); ?>
</div><!-- Entry Date -->